'use client';
import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import AppLogo from '@/components/ui/AppLogo';

const navLinks = [
  { label: 'About', href: '#about' },
  { label: 'Services', href: '#services' },
  { label: 'Process', href: '#process' },
  { label: 'Industries', href: '#industries' },
  { label: 'Pricing', href: '#engagement' },
];

export default function Header() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (menuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [menuOpen]);

  const handleNavClick = () => setMenuOpen(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? 'bg-primary/95 backdrop-blur-md shadow-lg shadow-primary/20'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2.5 group">
            <AppLogo
              src="/assets/images/logo_1-1786267820748.png"
              size={36}
              className="rounded-lg"
            />
            <span className="font-display font-700 text-xl text-white tracking-tight hidden sm:block">
              TaskNera
            </span>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navLinks?.map((link) => (
              <a
                key={link?.label}
                href={link?.href}
                className="px-4 py-2 text-sm font-medium text-white/75 hover:text-white transition-colors rounded-lg hover:bg-white/8"
              >
                {link?.label}
              </a>
            ))}
          </nav>

          {/* Desktop CTA */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/admin"
              className="text-sm font-semibold text-white/60 hover:text-white transition-colors"
            >
              Admin
            </Link>
            <Link
              href="/contact"
              className="text-sm font-semibold text-white/80 hover:text-white transition-colors"
            >
              Contact
            </Link>
            <a
              href="#contact"
              className="bg-accent text-accent-foreground text-sm font-semibold px-5 py-2.5 rounded-full hover:opacity-90 transition-all hover:-translate-y-0.5 shadow-lg shadow-accent/30"
            >
              Get in Touch
            </a>
          </div>

          {/* Mobile Hamburger */}
          <button
            className="md:hidden flex flex-col gap-1.5 p-2 rounded-lg hover:bg-white/10 transition-colors"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label={menuOpen ? 'Close menu' : 'Open menu'}
            aria-expanded={menuOpen}
          >
            <span
              className={`block w-5 h-0.5 bg-white transition-all duration-300 ${menuOpen ? 'rotate-45 translate-y-2' : ''}`}
            />
            <span
              className={`block w-5 h-0.5 bg-white transition-all duration-300 ${menuOpen ? 'opacity-0' : ''}`}
            />
            <span
              className={`block w-5 h-0.5 bg-white transition-all duration-300 ${menuOpen ? '-rotate-45 -translate-y-2' : ''}`}
            />
          </button>
        </div>
      </div>
      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div className="md:hidden fixed inset-0 top-16 bg-primary/98 backdrop-blur-xl z-40 flex flex-col">
          <nav className="flex flex-col px-6 pt-8 gap-2">
            {navLinks?.map((link) => (
              <a
                key={link?.label}
                href={link?.href}
                onClick={handleNavClick}
                className="text-lg font-semibold text-white/80 hover:text-white py-3 border-b border-white/10 transition-colors"
              >
                {link?.label}
              </a>
            ))}
          </nav>
          <div className="px-6 pt-8 flex flex-col gap-3">
            <Link
              href="/admin"
              onClick={handleNavClick}
              className="text-base font-semibold text-white/60 hover:text-white py-3 border-b border-white/10 transition-colors block"
            >
              Admin
            </Link>
            <Link
              href="/contact"
              onClick={handleNavClick}
              className="text-base font-semibold text-white/80 hover:text-white py-3 border-b border-white/10 transition-colors block"
            >
              Contact
            </Link>
            <a
              href="#contact"
              onClick={handleNavClick}
              className="bg-accent text-accent-foreground text-base font-semibold px-6 py-3.5 rounded-full text-center hover:opacity-90 transition-opacity"
            >
              Get in Touch
            </a>
            <a
              href="mailto:operations@tasknera.com"
              onClick={handleNavClick}
              className="text-white/60 text-sm text-center py-2"
            >
              operations@tasknera.com
            </a>
          </div>
        </div>
      )}
    </header>
  );
}