'use client';
import React from 'react';
import Icon from '@/components/ui/AppIcon';

/* BENTO GRID AUDIT (5 cards, 3-col grid):
   Array has 5 cards: [Success Fee, Dedicated Recruiter, Monthly RPO, Contract Staffing, Payroll Outsourcing]
   Row 1: [col-1: Success Fee cs-1] [col-2: Dedicated Recruiter cs-1] [col-3: Monthly RPO cs-1]
   Row 2: [col-1: Contract Staffing cs-1] [col-2+3: Payroll Outsourcing cs-2]
   Placed 5/5 ✓
*/

const models = [
  {
    icon: 'TrophyIcon',
    title: 'Success Fee Recruitment',
    desc: 'Pay only on successful placement. Ideal for permanent hiring with no upfront cost.',
    tag: 'No upfront cost',
    span: 'col-span-1',
    color: 'border-accent/30',
    bg: 'bg-accent/5',
  },
  {
    icon: 'UserCircleIcon',
    title: 'Dedicated Recruiter Model',
    desc: 'A full-time recruiter embedded in your team, aligned to your culture and pace.',
    tag: 'Embedded team',
    span: 'col-span-1',
    color: 'border-secondary/30',
    bg: 'bg-secondary/5',
  },
  {
    icon: 'ArrowPathIcon',
    title: 'Monthly RPO',
    desc: 'Outsource your entire recruitment function with SLA-backed delivery and reporting.',
    tag: 'Full outsource',
    span: 'col-span-1',
    color: 'border-primary/20',
    bg: 'bg-primary/5',
  },
  {
    icon: 'ClipboardDocumentListIcon',
    title: 'Contract Staffing',
    desc: 'Flexible contract talent for project-based, seasonal, or transitional workforce needs.',
    tag: 'Flexible tenure',
    span: 'col-span-1',
    color: 'border-accent/30',
    bg: 'bg-accent/5',
  },
  {
    icon: 'BanknotesIcon',
    title: 'Payroll Outsourcing',
    desc: 'End-to-end payroll processing, statutory compliance, and HRMS management — fully managed.',
    tag: 'Compliance guaranteed',
    span: 'sm:col-span-2',
    color: 'border-secondary/30',
    bg: 'bg-secondary/5',
  },
];

const journey = [
  { step: '01', title: 'Consultation', desc: 'Understand your needs and goals' },
  { step: '02', title: 'Proposal & SLA', desc: 'Tailored plan with clear deliverables' },
  { step: '03', title: 'Onboarding & Kickoff', desc: 'Team setup and process alignment' },
  { step: '04', title: 'Delivery & Reporting', desc: 'Ongoing execution with transparency' },
  { step: '05', title: 'Review & Scale', desc: 'Continuous improvement and growth' },
];

export default function EngagementModelsSection() {
  return (
    <section id="engagement" className="py-20 sm:py-28 bg-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-14 scroll-reveal">
          <div className="inline-flex items-center gap-2 bg-secondary/10 border border-secondary/20 rounded-full px-4 py-1.5 mb-5">
            <span className="w-1.5 h-1.5 rounded-full bg-secondary" />
            <span className="text-xs font-semibold text-secondary tracking-widest uppercase">Engagement Models</span>
          </div>
          <h2 className="text-section-title font-display font-700 text-foreground mb-4">
            Flexible Models,{' '}
            <span className="gradient-text-coral">Fixed Results</span>
          </h2>
          <p className="text-muted-foreground text-lg">
            Choose the engagement that fits your stage, size, and speed.
          </p>
        </div>

        {/* Bento grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-16 scroll-reveal" style={{ transitionDelay: '0.1s' }}>
          {models.map((model, i) => (
            <div
              key={model.title}
              className={`spotlight-card hover-lift bg-card border rounded-2xl p-6 shadow-sm flex flex-col gap-4 ${model.span} ${model.color} ${model.bg}`}
              style={{ transitionDelay: `${i * 0.07}s` }}
            >
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-xl bg-white border border-border shadow-sm flex items-center justify-center">
                  <Icon name={model.icon as 'TrophyIcon'} size={18} className="text-primary" variant="outline" />
                </div>
                <span className="text-xs font-semibold bg-white border border-border rounded-full px-3 py-1 text-muted-foreground">
                  {model.tag}
                </span>
              </div>
              <div>
                <h3 className="font-semibold text-foreground text-base mb-1.5">{model.title}</h3>
                <p className="text-muted-foreground text-sm leading-relaxed">{model.desc}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Client engagement journey */}
        <div className="scroll-reveal" style={{ transitionDelay: '0.2s' }}>
          <div className="bg-muted border border-border rounded-3xl p-6 sm:p-8">
            <div className="text-center mb-8">
              <h3 className="font-display font-700 text-foreground text-2xl">Client Engagement Journey</h3>
              <p className="text-muted-foreground text-sm mt-2">From first call to scaling — a clear, predictable path.</p>
            </div>

            {/* Horizontal journey steps */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-0">
              {journey.map((j, i) => (
                <React.Fragment key={j.step}>
                  <div className="flex sm:flex-col items-center sm:items-center gap-4 sm:gap-2 flex-1 min-w-0">
                    <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                      {j.step}
                    </div>
                    <div className="sm:text-center">
                      <div className="font-semibold text-foreground text-sm">{j.title}</div>
                      <div className="text-muted-foreground text-xs mt-0.5 leading-snug">{j.desc}</div>
                    </div>
                  </div>
                  {i < journey.length - 1 && (
                    <div className="hidden sm:block w-full h-px bg-border flex-shrink mx-1" />
                  )}
                </React.Fragment>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}