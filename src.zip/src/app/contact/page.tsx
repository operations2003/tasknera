'use client';
import React, { useState } from 'react';
import Link from 'next/link';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

interface FormData {
  name: string;
  email: string;
  company: string;
  phone: string;
  enquiry: string;
  project_details: string;
  message: string;
}

interface FormErrors {
  name?: string;
  email?: string;
  company?: string;
}

const initialForm: FormData = { name: '', email: '', company: '', phone: '', enquiry: 'hiring', project_details: '', message: '' };

function validateField(name: string, value: string): string | undefined {
  if (name === 'name') {
    if (!value.trim()) return 'Full name is required.';
    if (value.trim().length < 2) return 'Name must be at least 2 characters.';
  }
  if (name === 'email') {
    if (!value.trim()) return 'Work email is required.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())) return 'Please enter a valid email address.';
  }
  if (name === 'company') {
    if (value.trim().length > 0 && value.trim().length < 2) return 'Company name must be at least 2 characters.';
  }
  return undefined;
}

const teamMembers = [
  {
    name: 'Sheetal Bedi',
    role: 'Founder & CEO',
    bio: 'HR strategist with 15+ years building talent pipelines across India, UK, and the US. Sheetal founded TaskNera to make enterprise-grade HR accessible to every business.',
    email: 'sheetalbedi@tasknera.com',
    initials: 'SB',
    color: 'from-accent/30 to-accent/10',
  },
  {
    name: 'Operations Team',
    role: 'Business Enquiries',
    bio: 'Our dedicated operations team handles all inbound enquiries, client onboarding, and partnership discussions — with a 1-business-day response commitment.',
    email: 'operations@tasknera.com',
    initials: 'OT',
    color: 'from-purple-500/30 to-purple-500/10',
  },
  {
    name: 'Talent Desk',
    role: 'Careers & Candidate Support',
    bio: `Looking to join a client's team or explore opportunities through TaskNera? Our talent desk connects candidates with the right roles across 12+ industries.`,email: 'careers@tasknera.com',initials: 'TD',color: 'from-orange-400/30 to-orange-400/10',
  },
];

const offices = [
  {
    city: 'India HQ',
    address: 'Gurugram, Haryana',
    region: 'South Asia Operations',
    timezone: 'IST (UTC+5:30)',
    flag: '🇮🇳',
    coverage: 'Pan-India hiring, HR outsourcing, payroll compliance',
  },
  {
    city: 'United Kingdom',
    address: 'London, England',
    region: 'EMEA Operations',
    timezone: 'GMT / BST (UTC+0/+1)',
    flag: '🇬🇧',
    coverage: 'UK & European talent acquisition, cross-border staffing',
  },
  {
    city: 'United States',
    address: 'Remote-first, US',
    region: 'North America',
    timezone: 'EST / PST (UTC-5/-8)',
    flag: '🇺🇸',
    coverage: 'US market sourcing, remote-global talent pools',
  },
];

export default function ContactPage() {
  const [form, setForm] = useState<FormData>(initialForm);
  const [errors, setErrors] = useState<FormErrors>({});
  const [touched, setTouched] = useState<{ name?: boolean; email?: boolean; company?: boolean }>({});
  const [submitted, setSubmitted] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  function validateAll(): FormErrors {
    return {
      name: validateField('name', form.name),
      email: validateField('email', form.email),
      company: validateField('company', form.company),
    };
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (touched[name as keyof typeof touched]) {
      setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
    }
  }

  function handleBlur(e: React.FocusEvent<HTMLInputElement>) {
    const { name, value } = e.target;
    setTouched((prev) => ({ ...prev, [name]: true }));
    setErrors((prev) => ({ ...prev, [name]: validateField(name, value) }));
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const allErrors = validateAll();
    setErrors(allErrors);
    setTouched({ name: true, email: true, company: true });
    if (allErrors.name || allErrors.email || allErrors.company) return;
    setSubmitting(true);
    try {
      const { error } = await supabase.from('inquiry_submissions').insert({
        name: form.name,
        email: form.email,
        company: form.company || null,
        phone: form.phone || null,
        enquiry_type: form.enquiry,
        project_details: form.project_details || null,
        message: form.message,
      });
      if (error) throw error;
      try {
        await fetch(
          `${process.env.NEXT_PUBLIC_SUPABASE_URL}/functions/v1/send-inquiry-email`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY}`,
            },
            body: JSON.stringify({
              name: form.name,
              email: form.email,
              company: form.company || null,
              phone: form.phone || null,
              enquiry_type: form.enquiry,
              project_details: form.project_details || null,
              message: form.message,
            }),
          }
        );
      } catch (emailErr) {
        console.error('Email notification error:', emailErr);
      }
      setSubmitted(true);
    } catch (err) {
      console.error('Submission error:', err);
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <Header />
      <main className="bg-background min-h-screen">

        {/* ── Hero Banner ── */}
        <section className="bg-primary relative overflow-hidden pt-28 pb-20 sm:pt-36 sm:pb-28">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] blob-teal animate-pulse-slow pointer-events-none opacity-40" style={{ transform: 'translate(30%, -30%)' }} />
          <div className="absolute bottom-0 left-0 w-96 h-96 blob-coral animate-float-delayed pointer-events-none opacity-30" style={{ transform: 'translate(-30%, 40%)' }} />
          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl">
              <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 mb-6">
                <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                <span className="text-xs font-semibold text-white/80 tracking-widest uppercase">Contact Us</span>
              </div>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-700 text-white leading-tight mb-5">
                Let's start a{' '}
                <span className="gradient-text-coral">conversation.</span>
              </h1>
              <p className="text-white/60 text-lg leading-relaxed mb-8 max-w-xl">
                Whether you're scaling a team, outsourcing HR, or exploring a partnership — we respond within 1 business day.
              </p>
              <div className="flex flex-wrap gap-4">
                <a
                  href="#inquiry-form"
                  className="inline-flex items-center gap-2 glass-btn text-white font-semibold px-6 py-3 rounded-full text-sm"
                >
                  Fill the form
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 5v14M5 12l7 7 7-7"/></svg>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* ── Office Locations ── */}
        <section className="py-20 sm:py-24 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-12">
              <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 rounded-full px-4 py-1.5 mb-4">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                <span className="text-xs font-semibold text-accent tracking-widest uppercase">Global Presence</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-display font-700 text-foreground">
                Where we operate
              </h2>
            </div>

            {/* Asymmetric bento grid */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {offices.map((office, i) => (
                <div
                  key={office.city}
                  className={`bg-primary border border-white/10 rounded-3xl p-7 flex flex-col gap-4 hover:border-accent/40 transition-colors ${i === 0 ? 'md:col-span-5' : i === 1 ? 'md:col-span-4' : 'md:col-span-3'}`}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <span className="text-3xl">{office.flag}</span>
                    </div>
                    <span className="text-xs font-mono text-white/50 bg-white/10 px-2.5 py-1 rounded-full">{office.timezone}</span>
                  </div>
                  <div>
                    <h3 className="text-white font-display font-700 text-xl mb-0.5">{office.city}</h3>
                    <p className="text-white/55 text-sm">{office.address}</p>
                  </div>
                  <div className="mt-auto">
                    <span className="inline-block text-xs font-medium text-primary bg-accent border border-accent/60 rounded-full px-3 py-1">{office.region}</span>
                    <p className="text-white/50 text-xs mt-3 leading-relaxed">{office.coverage}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Team Details ── */}
        <section className="py-20 sm:py-24 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="mb-12">
              <div className="inline-flex items-center gap-2 bg-accent/10 border border-accent/20 rounded-full px-4 py-1.5 mb-4">
                <span className="w-1.5 h-1.5 rounded-full bg-accent" />
                <span className="text-xs font-semibold text-accent tracking-widest uppercase">Our Team</span>
              </div>
              <h2 className="text-3xl sm:text-4xl font-display font-700 text-foreground">
                Who you'll be talking to
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {teamMembers.map((member) => (
                <div
                  key={member.name}
                  className="bg-primary border border-white/10 rounded-3xl p-7 flex flex-col gap-5 hover:border-accent/40 transition-colors group"
                >
                  {/* Avatar */}
                  <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${member.color} flex items-center justify-center`}>
                    <span className="text-white font-display font-700 text-lg">{member.initials}</span>
                  </div>
                  <div>
                    <h3 className="text-white font-semibold text-base mb-0.5">{member.name}</h3>
                    <p className="text-accent text-xs font-medium tracking-wide">{member.role}</p>
                  </div>
                  <p className="text-white/60 text-sm leading-relaxed flex-1">{member.bio}</p>
                  <a
                    href={`mailto:${member.email}`}
                    className="inline-flex items-center gap-2 text-sm font-medium text-white/60 hover:text-accent transition-colors group-hover:text-accent"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/></svg>
                    {member.email}
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* ── Inquiry Form ── */}
        <section id="inquiry-form" className="py-20 sm:py-28 bg-primary relative overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 blob-teal animate-pulse-slow pointer-events-none opacity-40" style={{ transform: 'translate(30%, -30%)' }} />
          <div className="absolute bottom-0 left-0 w-80 h-80 blob-coral animate-float-delayed pointer-events-none opacity-30" style={{ transform: 'translate(-30%, 30%)' }} />

          <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            {!submitted ? (
              <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
                {/* Left */}
                <div>
                  <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 mb-6">
                    <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                    <span className="text-xs font-semibold text-white/80 tracking-widest uppercase">Send an Enquiry</span>
                  </div>
                  <h2 className="text-3xl sm:text-4xl font-display font-700 text-white mb-5">
                    Tell us what you need —{' '}
                    <span className="gradient-text-coral">we'll handle the rest.</span>
                  </h2>
                  <p className="text-white/60 text-base leading-relaxed mb-8">
                    Share your hiring challenge or HR requirement and a dedicated consultant will reach out with a tailored proposal.
                  </p>

                  {/* Contact cards */}
                  <div className="space-y-3">
                    {[
                      { icon: '✉️', label: 'Business Enquiries', value: 'operations@tasknera.com', href: 'mailto:operations@tasknera.com' },
                      { icon: '👔', label: 'Careers & Talent', value: 'careers@tasknera.com', href: 'mailto:careers@tasknera.com' },
                      { icon: '🌐', label: 'Website', value: 'www.tasknera.com', href: 'https://www.tasknera.com' },
                    ].map((c) => (
                      <a
                        key={c.label}
                        href={c.href}
                        className="glass-card rounded-2xl p-4 flex items-center gap-4 hover:bg-white/10 transition-colors group"
                      >
                        <div className="text-xl w-8 flex-shrink-0">{c.icon}</div>
                        <div>
                          <div className="text-white/50 text-xs mb-0.5">{c.label}</div>
                          <div className="text-white text-sm font-medium group-hover:text-accent transition-colors">{c.value}</div>
                        </div>
                      </a>
                    ))}
                  </div>
                </div>

                {/* Right — Form */}
                <div className="glass-card rounded-3xl p-7 sm:p-8">
                  <h3 className="text-white font-semibold text-lg mb-1">Send us a message</h3>
                  <p className="text-white/50 text-sm mb-6">We'll get back to you within 1 business day.</p>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-white/60 text-xs font-medium mb-1.5">Full Name <span className="text-accent">*</span></label>
                        <input
                          type="text"
                          name="name"
                          value={form.name}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          placeholder="Jane Smith"
                          className={`w-full border rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none transition-colors ${errors.name && touched.name ? 'border-red-400/70 focus:border-red-400' : 'border-white/15 focus:border-accent/60'}`}
                          style={{ background: 'rgba(255,255,255,0.06)' }}
                        />
                        {errors.name && touched.name && (
                          <p className="mt-1.5 text-red-400 text-xs flex items-center gap-1">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            {errors.name}
                          </p>
                        )}
                      </div>
                      <div>
                        <label className="block text-white/60 text-xs font-medium mb-1.5">Work Email <span className="text-accent">*</span></label>
                        <input
                          type="email"
                          name="email"
                          value={form.email}
                          onChange={handleChange}
                          onBlur={handleBlur}
                          placeholder="jane@company.com"
                          className={`w-full border rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none transition-colors ${errors.email && touched.email ? 'border-red-400/70 focus:border-red-400' : 'border-white/15 focus:border-accent/60'}`}
                          style={{ background: 'rgba(255,255,255,0.06)' }}
                        />
                        {errors.email && touched.email && (
                          <p className="mt-1.5 text-red-400 text-xs flex items-center gap-1">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            {errors.email}
                          </p>
                        )}
                      </div>
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs font-medium mb-1.5">Company</label>
                      <input
                        type="text"
                        name="company"
                        value={form.company}
                        onChange={handleChange}
                        onBlur={handleBlur}
                        placeholder="Acme Corp"
                        className={`w-full border rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none transition-colors ${errors.company && touched.company ? 'border-red-400/70 focus:border-red-400' : 'border-white/15 focus:border-accent/60'}`}
                        style={{ background: 'rgba(255,255,255,0.06)' }}
                      />
                      {errors.company && touched.company && (
                        <p className="mt-1.5 text-red-400 text-xs flex items-center gap-1">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                          {errors.company}
                        </p>
                      )}
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs font-medium mb-1.5">Phone Number</label>
                      <input
                        type="tel"
                        name="phone"
                        value={form.phone}
                        onChange={handleChange}
                        placeholder="+1 (555) 000-0000"
                        className="w-full border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none focus:border-accent/60 transition-colors"
                        style={{ background: 'rgba(255,255,255,0.06)' }}
                      />
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs font-medium mb-1.5">Enquiry Type</label>
                      <select
                        name="enquiry"
                        value={form.enquiry}
                        onChange={handleChange}
                        className="w-full border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-accent/60 transition-colors appearance-none"
                        style={{ background: 'rgba(255,255,255,0.06)' }}
                      >
                        <option value="hiring" className="bg-primary text-white">Hiring / Recruitment</option>
                        <option value="hr-outsourcing" className="bg-primary text-white">HR & Payroll Outsourcing</option>
                        <option value="staffing" className="bg-primary text-white">Contract Staffing</option>
                        <option value="rpo" className="bg-primary text-white">RPO / Talent Partnership</option>
                        <option value="other" className="bg-primary text-white">Other</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs font-medium mb-1.5">Project Details</label>
                      <textarea
                        name="project_details"
                        value={form.project_details}
                        onChange={handleChange}
                        rows={3}
                        placeholder="Briefly describe your project scope, timeline, or budget..."
                        className="w-full border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none focus:border-accent/60 transition-colors resize-none"
                        style={{ background: 'rgba(255,255,255,0.06)' }}
                      />
                    </div>
                    <div>
                      <label className="block text-white/60 text-xs font-medium mb-1.5">Message</label>
                      <textarea
                        name="message"
                        value={form.message}
                        onChange={handleChange}
                        rows={4}
                        placeholder="Tell us about your hiring needs or HR challenges..."
                        className="w-full border border-white/15 rounded-xl px-4 py-2.5 text-white text-sm placeholder-white/30 focus:outline-none focus:border-accent/60 transition-colors resize-none"
                        style={{ background: 'rgba(255,255,255,0.06)' }}
                      />
                    </div>
                    <button
                      type="submit"
                      disabled={submitting}
                      className="w-full bg-accent text-accent-foreground font-semibold py-3.5 rounded-xl hover:opacity-90 transition-all hover:-translate-y-0.5 shadow-xl shadow-accent/30 text-sm disabled:opacity-60 disabled:cursor-not-allowed disabled:translate-y-0 flex items-center justify-center gap-2"
                    >
                      {submitting ? (
                        <>
                          <svg className="animate-spin w-4 h-4" viewBox="0 0 24 24" fill="none">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" />
                          </svg>
                          Sending…
                        </>
                      ) : (
                        <>
                          Send Message
                          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                        </>
                      )}
                    </button>
                  </form>
                </div>
              </div>
            ) : (
              /* Success State */
              <div className="max-w-2xl mx-auto text-center">
                <div className="relative inline-flex items-center justify-center mb-8">
                  <div className="w-24 h-24 rounded-full bg-accent/20 border border-accent/30 flex items-center justify-center">
                    <div className="w-16 h-16 rounded-full bg-accent/30 flex items-center justify-center">
                      <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="#0fb88a" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M20 6L9 17l-5-5" />
                      </svg>
                    </div>
                  </div>
                  <div className="absolute inset-0 rounded-full blob-teal animate-pulse-slow" />
                </div>
                <div className="inline-flex items-center gap-2 bg-accent/15 border border-accent/25 rounded-full px-4 py-1.5 mb-5">
                  <span className="w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                  <span className="text-xs font-semibold text-accent tracking-widest uppercase">Message Received</span>
                </div>
                <h2 className="text-4xl font-display font-700 text-white mb-4">
                  Thank you,{' '}
                  <span className="gradient-text-coral">{form.name.split(' ')[0] || 'there'}!</span>
                </h2>
                <p className="text-white/70 text-lg leading-relaxed mb-10">
                  Your enquiry has been submitted. Our team will review your message and reach out within 1 business day.
                </p>
                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <button
                    onClick={() => { setSubmitted(false); setForm(initialForm); }}
                    className="inline-flex items-center justify-center gap-2 glass-btn text-white font-semibold px-7 py-3 rounded-full text-sm"
                  >
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M19 12H5M12 5l-7 7 7 7"/></svg>
                    Submit another enquiry
                  </button>
                  <Link
                    href="/"
                    className="inline-flex items-center justify-center gap-2 bg-accent text-accent-foreground font-semibold px-7 py-3 rounded-full text-sm hover:opacity-90 transition-all"
                  >
                    Back to home
                  </Link>
                </div>
              </div>
            )}
          </div>
        </section>

      </main>
      <Footer />
    </>
  );
}
